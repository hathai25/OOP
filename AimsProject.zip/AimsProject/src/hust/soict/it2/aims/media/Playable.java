package hust.soict.it2.aims.media;

import hust.soict.it2.aims.PlayerException;

public interface Playable {
	public void play() throws PlayerException;
}
