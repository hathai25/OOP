package hust.soict.it2.aims;

public class PlayerException extends Exception {
	public PlayerException (String error) {
		super(error);
	}
	
	public PlayerException() {
		
	}
}
